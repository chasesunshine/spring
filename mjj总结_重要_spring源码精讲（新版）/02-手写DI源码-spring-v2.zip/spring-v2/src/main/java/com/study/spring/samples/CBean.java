package com.study.spring.samples;

public class CBean {

	private String name;

	public CBean(String name) {
		this.name = name;
	}

	public String getName() {
		return this.name;
	}
}
