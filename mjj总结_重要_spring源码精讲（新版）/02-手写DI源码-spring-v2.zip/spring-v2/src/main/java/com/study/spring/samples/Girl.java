package com.study.spring.samples;

import lombok.Data;

@Data
public class Girl {
    private Boy boy;

}
