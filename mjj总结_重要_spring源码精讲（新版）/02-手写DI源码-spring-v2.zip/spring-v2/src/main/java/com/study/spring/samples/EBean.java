package com.study.spring.samples;

public class EBean {

	private DBean dbean;

	public EBean(DBean dbean) {
		super();
		this.dbean = dbean;
	}

}
