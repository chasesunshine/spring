package com.study.spring.samples;

public class CCBean extends CBean {

	public CCBean(String name) {
		super(name);
	}

}
