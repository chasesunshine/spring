package com.study.spring.samples;

public class DBean {

	private EBean ebean;

	public DBean(EBean ebean) {
		super();
		this.ebean = ebean;
	}
}
