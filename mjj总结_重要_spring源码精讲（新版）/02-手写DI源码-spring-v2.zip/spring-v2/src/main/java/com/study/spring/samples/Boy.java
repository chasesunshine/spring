package com.study.spring.samples;

import lombok.Data;

@Data
public class Boy {
    private Girl girl;
}
