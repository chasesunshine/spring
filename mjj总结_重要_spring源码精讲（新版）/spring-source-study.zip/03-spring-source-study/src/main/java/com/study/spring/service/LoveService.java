package com.study.spring.service;

public interface LoveService {

	void doLove();
}
