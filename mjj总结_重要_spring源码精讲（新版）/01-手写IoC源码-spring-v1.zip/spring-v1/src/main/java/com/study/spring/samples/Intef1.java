package com.study.spring.samples;

public interface Intef1 {
}
