package com.study.spring.samples;

public interface Interf3 extends Intef1,Interf2 {
}
