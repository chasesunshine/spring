package com.study.spring.beans;

public interface BeanFactory_v1 {
	/**
	 * 获取bean
	 */
	Object getBean(String name) throws Exception;
}
