package com.study.spring.samples;

public interface Interf4 {
}
